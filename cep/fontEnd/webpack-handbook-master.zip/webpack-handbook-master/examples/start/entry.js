// require('!style!css!./style.css')
require('./style.css')
document.write('It works.')
document.write(require('./module.js'))